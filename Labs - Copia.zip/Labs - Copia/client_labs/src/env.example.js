export const clientId = ''
export const clientSecret = ''
