export const clientId = '2'
export const clientSecret = '5oqBA1UY2yrCpCmPjpNRsAkuJR9Jn3R0rO0MqbaL'
