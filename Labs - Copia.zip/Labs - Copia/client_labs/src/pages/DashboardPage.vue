<template>
  <div id="dashboard-wrapper" class="wrapper">
      <p>Benvenuto sulla pagina principale</p>
  </div>
</template>
<script>
export default {
}
</script>
<style>
</style>
